from sharepoint import upload_to_sharepoint

if __name__ == "__main__":
    upload_to_sharepoint()
